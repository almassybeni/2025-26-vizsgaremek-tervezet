import React from 'react';

const Navigation = () => {
  return (
    <nav className="main-nav">
      <a href="#" className="active">Kezdőlap</a>
      <a href="#">Programok</a>
      <a href="#">Tájak</a>
      <a href="#">Gasztronómia</a>
      <a href="#">Rólunk</a>
    </nav>
  );
};

export default Navigation;