import React, { useState } from 'react';
import { MapPin, ChevronRight } from 'lucide-react';

const MapSection = () => {
  const regions = [
    { id: 1, name: 'Budapest', x: 65, y: 45, programCount: 42, color: '#8B4513' },
    { id: 2, name: 'Balaton', x: 40, y: 55, programCount: 38, color: '#4682B4' },
    { id: 3, name: 'Észak-Magyarország', x: 75, y: 30, programCount: 28, color: '#228B22' },
    { id: 4, name: 'Alföld', x: 60, y: 65, programCount: 32, color: '#DAA520' },
    { id: 5, name: 'Dunántúl', x: 30, y: 50, programCount: 26, color: '#DC143C' },
    { id: 6, name: 'Dél-Dunántúl', x: 35, y: 70, programCount: 18, color: '#9370DB' },
  ];

  const [selectedRegion, setSelectedRegion] = useState(null);

  return (
    <section className="map-section">
      <div className="container">
        <div className="section-header">
          <h2>Tájak & Régiók</h2>
          <p>Fedezd fel Magyarország gasztronómiai régióit</p>
        </div>
        
        <div className="map-container">
          <div className="hungary-map">
            {regions.map(region => (
              <button 
                key={region.id}
                className={`map-region ${selectedRegion === region.id ? 'selected' : ''}`}
                style={{
                  left: `${region.x}%`,
                  top: `${region.y}%`,
                  '--region-color': region.color
                }}
                onClick={() => setSelectedRegion(region.id)}
              >
                <div className="region-marker">
                  <MapPin size={20} />
                  <div className="region-info">
                    <h4>{region.name}</h4>
                    <p>{region.programCount} program</p>
                  </div>
                </div>
              </button>
            ))}
            
            {/* Egyszerűsített Magyarország térkép kontúr */}
            <div className="map-outline"></div>
          </div>
          
          <div className="region-details">
            {selectedRegion ? (
              <div>
                <h3>{regions.find(r => r.id === selectedRegion).name} gasztro ajánlatok</h3>
                <p>Fedezd fel a régió autentikus gasztronómiai kincseit, hagyományos ételeit és italait.</p>
                <ul className="region-highlights">
                  <li>Helyi termelők és kisiparosok</li>
                  <li>Gasztro fesztiválok és események</li>
                  <li>Kóstolók és tanfolyamok</li>
                  <li>Gasztro túrák és sétautak</li>
                </ul>
                <button className="btn-outline">Összes program ebben a régióban <ChevronRight size={16} /></button>
              </div>
            ) : (
              <div className="no-region-selected">
                <h3>Válassz egy régiót a térképről</h3>
                <p>Kattints egy régióra a részletek megtekintéséhez és a gasztronómiai programok felfedezéséhez.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default MapSection;