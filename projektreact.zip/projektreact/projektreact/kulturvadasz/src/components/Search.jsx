import React, { useState } from 'react';
import { MapPin, Search, Calendar, Filter } from 'lucide-react';

const SearchSection = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [region, setRegion] = useState('összes');
  const [date, setDate] = useState('');
  const [category, setCategory] = useState('összes');

  const handleSearch = (e) => {
    e.preventDefault();
    alert(`Keresés: ${searchTerm}, Régió: ${region}, Dátum: ${date}, Kategória: ${category}`);
  };

  return (
    <section className="search-section">
      <div className="container">
        <h2>Fedezd fel gasztronómiai kincseinket</h2>
        <p className="section-subtitle">Találd meg az igazán autentikus gasztroélményeket</p>
        
        <form className="search-form" onSubmit={handleSearch}>
          <div className="search-input-group">
            <div className="input-with-icon">
              <Search size={20} />
              <input 
                type="text" 
                placeholder="Mit keresel? Pl: borászat, sajtkészítés, pálinka fesztivál..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div className="input-with-icon">
              <MapPin size={20} />
              <select value={region} onChange={(e) => setRegion(e.target.value)}>
                <option value="összes">Összes régió</option>
                <option value="balaton">Balaton</option>
                <option value="budapest">Budapest</option>
                <option value="alfold">Alföld</option>
                <option value="dunantul">Dunántúl</option>
                <option value="eszak-magyarorszag">Észak-Magyarország</option>
              </select>
            </div>
            
            <div className="input-with-icon">
              <Calendar size={20} />
              <input 
                type="date" 
                value={date}
                onChange={(e) => setDate(e.target.value)}
              />
            </div>
            
            <div className="input-with-icon">
              <Filter size={20} />
              <select value={category} onChange={(e) => setCategory(e.target.value)}>
                <option value="összes">Összes kategória</option>
                <option value="fesztival">Gasztro Fesztivál</option>
                <option value="helyi-termek">Helyi termékek</option>
                <option value="kostoló">Kóstoló</option>
                <option value="tanfolyam">Tanfolyam</option>
                <option value="túra">Gasztro túra</option>
              </select>
            </div>
            
            <button type="submit" className="btn-search">
              <Search size={20} /> Keresés
            </button>
          </div>
        </form>
        
        <div className="quick-filters">
          <span>Gyors szűrők:</span>
          <button className="filter-chip">Hétvégi program</button>
          <button className="filter-chip">Családbarát</button>
          <button className="filter-chip">Ingyenes</button>
          <button className="filter-chip">Vegán</button>
          <button className="filter-chip">Bor & Borkóstoló</button>
        </div>
      </div>
    </section>
  );
};

export default SearchSection;