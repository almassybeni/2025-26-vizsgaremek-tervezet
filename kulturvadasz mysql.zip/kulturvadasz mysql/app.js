const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

// Adatbázis kapcsolat létrehozása
const pool = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// ==================== FELHASZNÁLÓK VÉGPONTOK ====================

// GET - Összes felhasználó listázása
app.get('/api/felhasznalok', async (req, res) => {
    try {
        const [rows] = await pool.query(`
            SELECT f.id, f.email, f.nev, f.telefon, f.aktiv, f.letrehozva, 
                   GROUP_CONCAT(sz.Nev) as szerepkorok
            FROM felhasznalo f
            LEFT JOIN felhasznalo_szerep fs ON f.id = fs.felhasznalo_id
            LEFT JOIN szerepkor sz ON fs.szerepkor_id = sz.id
            GROUP BY f.id
        `);
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// GET - Egy felhasználó lekérése ID alapján
app.get('/api/felhasznalok/:id', async (req, res) => {
    try {
        const [rows] = await pool.query(`
            SELECT f.*, GROUP_CONCAT(sz.Nev) as szerepkorok
            FROM felhasznalo f
            LEFT JOIN felhasznalo_szerep fs ON f.id = fs.felhasznalo_id
            LEFT JOIN szerepkor sz ON fs.szerepkor_id = sz.id
            WHERE f.id = ?
            GROUP BY f.id
        `, [req.params.id]);
        
        if (rows.length === 0) {
            return res.status(404).json({ message: 'Felhasználó nem található' });
        }
        res.json(rows[0]);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// POST - Új felhasználó létrehozása
app.post('/api/felhasznalok', async (req, res) => {
    const { email, jelszo, nev, telefon, szerepkor_id } = req.body;
    
    if (!email || !jelszo || !nev) {
        return res.status(400).json({ message: 'Email, jelszó és név megadása kötelező' });
    }
    
    const connection = await pool.getConnection();
    
    try {
        await connection.beginTransaction();
        
        // Jelszó hash-elése
        const jelszo_hash = await bcrypt.hash(jelszo, 10);
        
        // Felhasználó beszúrása
        const [result] = await connection.query(
            'INSERT INTO felhasznalo (email, jelszo_hash, nev, telefon) VALUES (?, ?, ?, ?)',
            [email, jelszo_hash, nev, telefon || null]
        );
        
        // Szerepkör hozzárendelése (alapértelmezett: 3 - látogató)
        const szerepId = szerepkor_id || 3;
        await connection.query(
            'INSERT INTO felhasznalo_szerep (felhasznalo_id, szerepkor_id) VALUES (?, ?)',
            [result.insertId, szerepId]
        );
        
        await connection.commit();
        
        res.status(201).json({ 
            id: result.insertId, 
            message: 'Felhasználó sikeresen létrehozva' 
        });
    } catch (error) {
        await connection.rollback();
        if (error.code === 'ER_DUP_ENTRY') {
            res.status(400).json({ message: 'Ez az email cím már használatban van' });
        } else {
            res.status(500).json({ error: error.message });
        }
    } finally {
        connection.release();
    }
});

// PUT - Felhasználó módosítása
app.put('/api/felhasznalok/:id', async (req, res) => {
    const { email, nev, telefon, aktiv, szerepkorok } = req.body;
    const connection = await pool.getConnection();
    
    try {
        await connection.beginTransaction();
        
        // Felhasználó adatainak módosítása
        await connection.query(
            'UPDATE felhasznalo SET email = ?, nev = ?, telefon = ?, aktiv = ? WHERE id = ?',
            [email, nev, telefon, aktiv, req.params.id]
        );
        
        // Szerepkörök frissítése ha meg lettek adva
        if (szerepkorok && Array.isArray(szerepkorok)) {
            // Régi szerepkörök törlése
            await connection.query('DELETE FROM felhasznalo_szerep WHERE felhasznalo_id = ?', [req.params.id]);
            
            // Új szerepkörök beszúrása
            for (const szerepkorId of szerepkorok) {
                await connection.query(
                    'INSERT INTO felhasznalo_szerep (felhasznalo_id, szerepkor_id) VALUES (?, ?)',
                    [req.params.id, szerepkorId]
                );
            }
        }
        
        await connection.commit();
        res.json({ message: 'Felhasználó sikeresen módosítva' });
    } catch (error) {
        await connection.rollback();
        res.status(500).json({ error: error.message });
    } finally {
        connection.release();
    }
});

// DELETE - Felhasználó törlése
app.delete('/api/felhasznalok/:id', async (req, res) => {
    try {
        const [result] = await pool.query('DELETE FROM felhasznalo WHERE id = ?', [req.params.id]);
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Felhasználó nem található' });
        }
        
        res.json({ message: 'Felhasználó sikeresen törölve' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ==================== JELENTKEZÉSEK VÉGPONTOK ====================

// GET - Összes jelentkezés listázása
app.get('/api/jelentkezesek', async (req, res) => {
    try {
        const [rows] = await pool.query(`
            SELECT j.*, f.nev as felhasznalo_nev, t.nev as tura_nev, tp.nev as telepules_nev
            FROM jelentkezes j
            JOIN felhasznalo f ON j.felhasznalo_id = f.id
            JOIN turafajta t ON j.turafajta_id = t.id
            JOIN telepules tp ON j.irszam = tp.irszam
            ORDER BY j.datum DESC
        `);
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// GET - Egy jelentkezés lekérése ID alapján
app.get('/api/jelentkezesek/:id', async (req, res) => {
    try {
        const [rows] = await pool.query(`
            SELECT j.*, f.nev as felhasznalo_nev, t.nev as tura_nev, tp.nev as telepules_nev
            FROM jelentkezes j
            JOIN felhasznalo f ON j.felhasznalo_id = f.id
            JOIN turafajta t ON j.turafajta_id = t.id
            JOIN telepules tp ON j.irszam = tp.irszam
            WHERE j.id = ?
        `, [req.params.id]);
        
        if (rows.length === 0) {
            return res.status(404).json({ message: 'Jelentkezés nem található' });
        }
        res.json(rows[0]);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// POST - Új jelentkezés létrehozása
app.post('/api/jelentkezesek', async (req, res) => {
    const { felhasznalo_id, irszam, turafajta_id, datum, letszam, megjegyzes } = req.body;
    
    if (!felhasznalo_id || !irszam || !turafajta_id || !datum) {
        return res.status(400).json({ message: 'Hiányzó kötelező adatok' });
    }
    
    try {
        const [result] = await pool.query(
            `INSERT INTO jelentkezes (felhasznalo_id, irszam, turafajta_id, datum, letszam, megjegyzes) 
             VALUES (?, ?, ?, ?, ?, ?)`,
            [felhasznalo_id, irszam, turafajta_id, datum, letszam || 1, megjegyzes || null]
        );
        
        res.status(201).json({ 
            id: result.insertId, 
            message: 'Jelentkezés sikeresen létrehozva' 
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// PUT - Jelentkezés módosítása
app.put('/api/jelentkezesek/:id', async (req, res) => {
    const { irszam, turafajta_id, datum, letszam, megjegyzes } = req.body;
    
    try {
        const [result] = await pool.query(
            `UPDATE jelentkezes 
             SET irszam = ?, turafajta_id = ?, datum = ?, letszam = ?, megjegyzes = ?
             WHERE id = ?`,
            [irszam, turafajta_id, datum, letszam, megjegyzes, req.params.id]
        );
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Jelentkezés nem található' });
        }
        
        res.json({ message: 'Jelentkezés sikeresen módosítva' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// DELETE - Jelentkezés törlése
app.delete('/api/jelentkezesek/:id', async (req, res) => {
    try {
        const [result] = await pool.query('DELETE FROM jelentkezes WHERE id = ?', [req.params.id]);
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Jelentkezés nem található' });
        }
        
        res.json({ message: 'Jelentkezés sikeresen törölve' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ==================== TELEPÜLÉSEK VÉGPONTOK ====================

// GET - Összes település listázása
app.get('/api/telepulesek', async (req, res) => {
    try {
        const [rows] = await pool.query(`
            SELECT t.*, tj.nev as tajegyseg_nev
            FROM telepules t
            LEFT JOIN tajegyseg tj ON t.tajegyseg_id = tj.id
        `);
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// POST - Új település hozzáadása
app.post('/api/telepulesek', async (req, res) => {
    const { irszam, nev, tajegyseg_id } = req.body;
    
    if (!irszam || !nev) {
        return res.status(400).json({ message: 'Irányítószám és név megadása kötelező' });
    }
    
    try {
        const [result] = await pool.query(
            'INSERT INTO telepules (irszam, nev, tajegyseg_id) VALUES (?, ?, ?)',
            [irszam, nev, tajegyseg_id || null]
        );
        
        res.status(201).json({ 
            irszam: result.insertId, 
            message: 'Település sikeresen hozzáadva' 
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// PUT - Település módosítása
app.put('/api/telepulesek/:irszam', async (req, res) => {
    const { nev, tajegyseg_id } = req.body;
    
    try {
        const [result] = await pool.query(
            'UPDATE telepules SET nev = ?, tajegyseg_id = ? WHERE irszam = ?',
            [nev, tajegyseg_id, req.params.irszam]
        );
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Település nem található' });
        }
        
        res.json({ message: 'Település sikeresen módosítva' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// DELETE - Település törlése
app.delete('/api/telepulesek/:irszam', async (req, res) => {
    try {
        const [result] = await pool.query('DELETE FROM telepules WHERE irszam = ?', [req.params.irszam]);
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Település nem található' });
        }
        
        res.json({ message: 'Település sikeresen törölve' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ==================== TÚRAFAJTÁK VÉGPONTOK ====================

// GET - Összes túrafajta listázása
app.get('/api/turafajtak', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM turafajta ORDER BY nev');
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// POST - Új túrafajta hozzáadása
app.post('/api/turafajtak', async (req, res) => {
    const { nev } = req.body;
    
    if (!nev) {
        return res.status(400).json({ message: 'Név megadása kötelező' });
    }
    
    try {
        const [result] = await pool.query('INSERT INTO turafajta (nev) VALUES (?)', [nev]);
        res.status(201).json({ id: result.insertId, message: 'Túrafajta sikeresen hozzáadva' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// PUT - Túrafajta módosítása
app.put('/api/turafajtak/:id', async (req, res) => {
    const { nev } = req.body;
    
    try {
        const [result] = await pool.query('UPDATE turafajta SET nev = ? WHERE id = ?', [nev, req.params.id]);
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Túrafajta nem található' });
        }
        
        res.json({ message: 'Túrafajta sikeresen módosítva' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// DELETE - Túrafajta törlése
app.delete('/api/turafajtak/:id', async (req, res) => {
    try {
        const [result] = await pool.query('DELETE FROM turafajta WHERE id = ?', [req.params.id]);
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Túrafajta nem található' });
        }
        
        res.json({ message: 'Túrafajta sikeresen törölve' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ==================== TÁJEGYSÉGEK VÉGPONTOK ====================

// GET - Összes tájegység listázása
app.get('/api/tajegysegek', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM tajegyseg ORDER BY nev');
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// POST - Új tájegység hozzáadása
app.post('/api/tajegysegek', async (req, res) => {
    const { nev } = req.body;
    
    if (!nev) {
        return res.status(400).json({ message: 'Név megadása kötelező' });
    }
    
    try {
        const [result] = await pool.query('INSERT INTO tajegyseg (nev) VALUES (?)', [nev]);
        res.status(201).json({ id: result.insertId, message: 'Tájegység sikeresen hozzáadva' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// PUT - Tájegység módosítása
app.put('/api/tajegysegek/:id', async (req, res) => {
    const { nev } = req.body;
    
    try {
        const [result] = await pool.query('UPDATE tajegyseg SET nev = ? WHERE id = ?', [nev, req.params.id]);
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Tájegység nem található' });
        }
        
        res.json({ message: 'Tájegység sikeresen módosítva' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// DELETE - Tájegység törlése
app.delete('/api/tajegysegek/:id', async (req, res) => {
    try {
        const [result] = await pool.query('DELETE FROM tajegyseg WHERE id = ?', [req.params.id]);
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Tájegység nem található' });
        }
        
        res.json({ message: 'Tájegység sikeresen törölve' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ==================== SZEREPKÖRÖK VÉGPONTOK ====================

// GET - Összes szerepkör listázása
app.get('/api/szerepkorok', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM szerepkor ORDER BY id');
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ==================== STATISZTIKAI VÉGPONTOK ====================

// GET - Statisztikák
app.get('/api/statisztikak', async (req, res) => {
    try {
        // Felhasználók száma szerepkörönként
        const [felhasznalokSzerepkoronkent] = await pool.query(`
            SELECT sz.Nev, COUNT(fs.felhasznalo_id) as darab
            FROM szerepkor sz
            LEFT JOIN felhasznalo_szerep fs ON sz.id = fs.szerepkor_id
            GROUP BY sz.id
        `);
        
        // Jelentkezések túrafajtánként
        const [jelentkezesekTurafajtankent] = await pool.query(`
            SELECT t.nev, COUNT(j.id) as darab, SUM(j.letszam) as ossz_letszam
            FROM turafajta t
            LEFT JOIN jelentkezes j ON t.id = j.turafajta_id
            GROUP BY t.id
        `);
        
        // Jelentkezések településenként
        const [jelentkezesekTelepulesenkent] = await pool.query(`
            SELECT tp.nev, COUNT(j.id) as darab
            FROM telepules tp
            LEFT JOIN jelentkezes j ON tp.irszam = j.irszam
            GROUP BY tp.irszam
        `);
        
        res.json({
            felhasznalok_szerepkoronkent: felhasznalokSzerepkoronkent,
            jelentkezesek_turafajtankent: jelentkezesekTurafajtankent,
            jelentkezesek_telepulesenkent: jelentkezesekTelepulesenkent
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Szerver indítása
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Szerver fut a http://localhost:${PORT} címen`);
});